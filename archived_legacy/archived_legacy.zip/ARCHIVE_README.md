# Archive Legacy - 2025-09-12 02:20:39

## Contenu archivé

- **ancien_system/**: Ancien système IBKR/Polygon (remplacé par Sierra-only)
- **archive/**: Anciens fichiers d'archive (réorganisés)
- **Fichiers *.backup**: Sauvegardes automatiques

## Raison de l'archivage

Ces dossiers et fichiers créaient de la confusion dans le projet et ne sont plus utilisés
dans l'architecture Sierra-only actuelle.

## Restauration

Si nécessaire, les fichiers peuvent être restaurés depuis les archives ZIP
dans ce dossier.

## Impact

- ✅ Réduction de la confusion dans le projet
- ✅ Structure plus claire
- ✅ Aucun import cassé (vérifié)
- ✅ Historique préservé dans les archives
