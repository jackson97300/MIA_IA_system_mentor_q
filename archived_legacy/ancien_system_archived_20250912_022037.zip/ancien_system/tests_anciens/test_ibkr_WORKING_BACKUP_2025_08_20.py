#!/usr/bin/env python3
"""
Script de test IBKR corrigé avec détection automatique des contrats
"""

from ib_insync import *
import datetime as dt
import argparse

def wait_quotes(ib, ticker, tries=10):
    for _ in range(tries):
        ib.waitOnUpdate(timeout=1.0)
        if ticker.bid or ticker.ask or ticker.last:
            return True
    return False

def wait_greeks(ib, ticker, tries=20):
    for _ in range(tries):
        ib.waitOnUpdate(timeout=1.0)
        if ticker.modelGreeks:
            return True
    return False

def test_ibkr_corrige(host: str = '127.0.0.1', port: int = 7496, client_id: int = 7):
    """Test de connexion IBKR avec corrections"""
    print("🚀 TEST CONNEXION IBKR CORRIGÉ")
    print("=" * 40)
    
    ib = IB()
    try:
        # Connexion Paper
        print(f"Tentative de connexion → host={host}, port={port}, clientId={client_id}")
        ib.connect(host, port, clientId=client_id)
        print("✅ Connexion réussie")
        print(f"TWS time: {ib.reqCurrentTime()}")
        
        # Vérifier le compte connecté
        accounts = ib.managedAccounts()
        print(f"Comptes disponibles: {accounts}")
        acc = accounts[0] if accounts else ''

        def is_paper_du(a: str) -> bool:
            # vrai DU = 'DU' + chiffres (pas 'DUM...')
            return len(a) >= 3 and a[:2] == 'DU' and a[2].isdigit()

        if acc.startswith('DUM'):
            raise RuntimeError(f"Demo détecté ({acc}). Ferme TWS Demo et ouvre TWS Paper (DU…).")
        elif acc.startswith('U'):
            print("⚠️ Live détecté (7496). Pour tester: DU… (7497).")
        elif is_paper_du(acc):
            print("✅ Paper détecté.")
        else:
            raise RuntimeError(f"Compte non reconnu: {acc}")
        
        # Forcer le mode live market data
        ib.reqMarketDataType(1)  # 1=REALTIME, 3=DELAYED
        print("✅ Market data mode: REALTIME")
        
        # -------- ES FUTURES (résolution robuste) --------
        print("\n📊 TEST ES FUTURES:")
        
        # Diagnostic préliminaire
        matches = ib.reqMatchingSymbols('ES')
        print(f"[MATCH] ES: {len(matches)} résultats")
        for m in matches[:6]:
            print(f"  {m}")
        
        def pick_front_month(details):
            today = dt.datetime.now(dt.timezone.utc).strftime('%Y%m%d')
            cds = [d.contract for d in details if d.contract.lastTradeDateOrContractMonth]
            cds.sort(key=lambda c: c.lastTradeDateOrContractMonth)
            for c in cds:
                if c.lastTradeDateOrContractMonth >= today:
                    return c
            return cds[0] if cds else None
        
        found = None
        
        # 1) Essayer GLOBEX puis CME
        for ex in ("GLOBEX", "CME"):
            base = Future('ES', exchange=ex)
            det = ib.reqContractDetails(base)
            print(f"[TRY] ES on {ex}: {len(det)} candidates")
            if det:
                found = pick_front_month(det)
                if found:
                    break
        
        # 2) Si rien, tenter des contrats datés (prochains trimestres)
        if not found:
            year = dt.datetime.now(dt.timezone.utc).year
            for ym in (f"{year}09", f"{year}12", f"{year+1}03"):
                for ex in ("GLOBEX", "CME"):
                    cand = Future('ES', lastTradeDateOrContractMonth=ym, exchange=ex)
                    det = ib.reqContractDetails(cand)
                    print(f"[TRY] ES {ym} on {ex}: {len(det)} candidates")
                    if det:
                        found = det[0].contract
                        break
                if found:
                    break
        
        # 3) Dernier recours : localSymbol (ex: ESU5, ESZ5…)
        if not found:
            year_digit = dt.datetime.now(dt.timezone.utc).year % 10  # 2025 -> 5
            for ls in (f"ESU{year_digit}", f"ESZ{year_digit}"):
                for ex in ("CME", "GLOBEX"):
                    cand = Future(localSymbol=ls, exchange=ex)
                    det = ib.reqContractDetails(cand)
                    print(f"[TRY] localSymbol {ls} on {ex}: {len(det)} candidates")
                    if det:
                        found = det[0].contract
                        break
                if found:
                    break
        
        if not found:
            print("❌ ES introuvable → très probable : permission Futures (US) pas encore effective ou TWS non redémarré.")
        else:
            print(f"✅ ES sélectionné: {found.localSymbol} {found.lastTradeDateOrContractMonth} {found.exchange}")
            
            # L1 avec attente robuste
            tkr_es = ib.reqMktData(found, '', False)
            for _ in range(12): ib.waitOnUpdate(timeout=1.0)
            print(f"ES L1: Bid={tkr_es.bid}, Ask={tkr_es.ask}, Last={tkr_es.last}")
            
            # DOM L2 (CME Depth requis)
            try:
                dom = ib.reqMktDepth(found, numRows=10)
                for _ in range(5): ib.waitOnUpdate(timeout=1.0)
                print("ES DOM bids (top 5):", [(l.price, l.size) for l in dom.domBids[:5]])
                print("ES DOM asks (top 5):", [(l.price, l.size) for l in dom.domAsks[:5]])
                if not dom.domBids and not dom.domAsks:
                    print("⚠️ DOM vide → vérifier TWS (usfuture connected) et abonnement CME L2; puis redémarrer TWS.")
            except Exception as e:
                print("❌ DOM L2 error:", e)
        
        # -------- SPX OPTIONS (détection propre) --------
        print("\n📈 TEST SPX OPTIONS:")

        # 1) Récupérer le conId de l'index SPX (CBOE)
        spx_idx = Index('SPX', 'CBOE')
        cd = ib.reqContractDetails(spx_idx)
        if not cd:
            print("❌ SPX index introuvable → 'Index Options (US – CBOE/C2)' non active sur le compte ou TWS à redémarrer.")
        else:
            uconid = cd[0].contract.conId
            print("SPX index conId:", uconid)

            # 2) Lire la chaîne avec le VRAI underlyingConId
            params = ib.reqSecDefOptParams('SPX', '', 'IND', uconid)
            if not params or not params[0].expirations:
                print("❌ Chaîne SPX vide → autorisation 'Options sur indice – US (CBOE/C2)' indisponible/inactive.")
            else:
                p = params[0]
                expiries = sorted(p.expirations)
                strikes = sorted(float(s) for s in p.strikes if s is not None)

                # 3) Choix ATM SPX robuste
                from statistics import median
                
                # 1) tenter le spot index
                t_spx = ib.reqMktData(spx_idx, '', False)
                for _ in range(15): ib.waitOnUpdate(timeout=1.0)
                px = t_spx.last or t_spx.close or ((t_spx.bid + t_spx.ask) / 2 if t_spx.bid and t_spx.ask else None)
                
                # 2) si toujours None, probe via Greeks pour récupérer undPrice
                if not px:
                    mid_strike = median(strikes)
                    probe = Option('SPX', expiries[0], mid_strike, 'C', 'CBOE', 'USD')
                    ib.qualifyContracts(probe)
                    tk = ib.reqMktData(probe, genericTickList='106', snapshot=False)
                    for _ in range(12): ib.waitOnUpdate(timeout=1.0)
                    px = getattr(tk.modelGreeks, 'undPrice', None) or mid_strike
                    if px != mid_strike:
                        print(f"⚠️ SPX spot via Greeks fallback: {px}")
                
                # 3) choisir l'ATM final
                strike = min(strikes, key=lambda k: abs(k - px))
                expiry = expiries[0]
                print(f"SPX spot: {px}, Chosen strike: {strike}, expiry: {expiry}")

                # 4) Construire l'option CBOE avec tradingClass correct
                def is_third_friday(yyyymmdd: str) -> bool:
                    d = dt.datetime.strptime(yyyymmdd, "%Y%m%d").date()
                    return d.weekday() == 4 and 15 <= d.day <= 21  # vendredi et 15–21 => 3e vendredi

                def qualify_spx_option(ib, expiry: str, strike: float, right='C'):
                    # 1) Choisir la classe attendue
                    tr_class = 'SPX' if is_third_friday(expiry) else 'SPXW'
                    # 2) Essayer plusieurs places
                    for ex in ('CBOE', 'CBOE2', 'SMART'):
                        opt = Option('SPX', expiry, strike, right,
                                     exchange=ex, currency='USD',
                                     tradingClass=tr_class, multiplier='100')
                        cds = ib.reqContractDetails(opt)
                        if cds:
                            return cds[0].contract
                    # 3) Fallback : si SPXW introuvable, tester la mensuelle SPX sur la même date (rare)
                    if tr_class == 'SPXW':
                        for ex in ('CBOE','CBOE2','SMART'):
                            opt = Option('SPX', expiry, strike, right,
                                         exchange=ex, currency='USD',
                                         tradingClass='SPX', multiplier='100')
                            cds = ib.reqContractDetails(opt)
                            if cds:
                                return cds[0].contract
                    return None

                opt = qualify_spx_option(ib, expiry, strike, 'C')
                if not opt:
                    # aide au debug : montre les 5 premières échéances et 10 strikes autour d'ATM
                    print("❌ SPX option introuvable pour", expiry, strike, "(SPXW/SPX). Essaie une autre place ou une autre expiry.")
                else:
                    print(f"SPX option ({opt.tradingClass} @ {opt.exchange}):", opt.localSymbol)
                    tkr_opt = ib.reqMktData(opt, genericTickList='106', snapshot=False)
                    
                    # Attente optimisée pour les Greeks
                    for _ in range(30):  # passe de 15 à 30 itérations (~30s max)
                        ib.waitOnUpdate(timeout=1.0)
                        if tkr_opt.modelGreeks:
                            break

                    if not tkr_opt.modelGreeks:
                        # 1 relance propre si toujours None (réseau lent / changement d'underlying)
                        ib.cancelMktData(opt)
                        tkr_opt = ib.reqMktData(opt, genericTickList='106', snapshot=False)
                        for _ in range(20):
                            ib.waitOnUpdate(timeout=1.0)
                            if tkr_opt.modelGreeks:
                                break

                    print("SPX Greeks:", tkr_opt.modelGreeks)
        
        # -------- VIX (spot + futures + DOM) --------
        print("\n📊 TEST VIX:")
        
        # VIX spot (CBOE)
        vix_idx = Index('VIX', 'CBOE')
        ib.qualifyContracts(vix_idx)
        
        # 1) Live
        ib.reqMarketDataType(1)
        tkr_vix = ib.reqMktData(vix_idx, '', False)
        for _ in range(15): ib.waitOnUpdate(timeout=1.0)
        spot = tkr_vix.last or (tkr_vix.bid and tkr_vix.ask and (tkr_vix.bid + tkr_vix.ask) / 2) or tkr_vix.close

        # 2) Fallback delayed si toujours None
        if spot is None:
            ib.cancelMktData(vix_idx)
            ib.reqMarketDataType(3)  # DELAYED
            tkr_vix = ib.reqMktData(vix_idx, '', False)
            for _ in range(10): ib.waitOnUpdate(timeout=1.0)
            spot = tkr_vix.last or (tkr_vix.bid and tkr_vix.ask and (tkr_vix.bid + tkr_vix.ask) / 2) or tkr_vix.close

        print(f"VIX spot: {spot if spot is not None else 'NaN (données temporairement indisponibles)'}")
        
        # VX futures (CFE)
        print('\n== VX futures ==')
        vx_details = ib.reqContractDetails(Future('VX', exchange='CFE'))
        if not vx_details:
            print("❌ Toujours rien → perm CFE non activée/propagée ou TWS à redémarrer.")
        else:
            expiries = sorted({d.contract.lastTradeDateOrContractMonth for d in vx_details if d.contract.lastTradeDateOrContractMonth})
            print("VX expiries:", expiries[:6])
            
            by_exp = {}
            for d in vx_details:
                c = d.contract
                if c.lastTradeDateOrContractMonth:
                    by_exp[c.lastTradeDateOrContractMonth] = c
            vx_contracts = [by_exp[k] for k in sorted(by_exp.keys())]
            
            for c in vx_contracts[:4]:
                ib.qualifyContracts(c)
                tk = ib.reqMktData(c, '', False)
                for _ in range(10): ib.waitOnUpdate(timeout=1.0)
                print(f'VX {c.lastTradeDateOrContractMonth}: {tk.bid}, {tk.ask}, {tk.last}')

            # DOM sur le front-month
            try:
                dom_vx = ib.reqMktDepth(vx_contracts[0], numRows=10)
                for _ in range(5): ib.waitOnUpdate(timeout=1.0)
                print('VX DOM bids top3:', [(l.price, l.size) for l in dom_vx.domBids[:3]])
                print('VX DOM asks top3:', [(l.price, l.size) for l in dom_vx.domAsks[:3]])
            except Exception as e:
                print('❌ DOM VX error:', e)
        
    except Exception as e:
        print(f"❌ Erreur générale: {e}")
        print("\n🔧 SOLUTIONS:")
        print("1. Vérifiez que TWS/Gateway est lancé")
        print("2. Vérifiez le port (7497 pour Paper)")
        print("3. Vérifiez les abonnements data (CME, OPRA, CFE)")
        print("4. Changez clientId si nécessaire")
    
    finally:
        ib.disconnect()
        print("\n✅ Test terminé")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Script de test IBKR corrigé")
    parser.add_argument("--host", type=str, default="127.0.0.1", help="Hôte TWS/IBG")
    parser.add_argument("--port", type=int, default=7496, help="Port API (TWS Live=7496, TWS Paper=7497, Gateway Paper=4002)")
    parser.add_argument("--clientId", type=int, default=7, help="Identifiant client unique")
    args = parser.parse_args()

    test_ibkr_corrige(host=args.host, port=args.port, client_id=args.clientId)
